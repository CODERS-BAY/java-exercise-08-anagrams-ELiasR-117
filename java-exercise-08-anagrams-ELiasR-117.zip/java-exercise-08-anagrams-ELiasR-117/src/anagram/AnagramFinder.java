package anagram;

import java.util.Arrays;

public class AnagramFinder {

    public static void main(String[] args) {
        /*
            Write some tests here
         */
        areAnagrams("AVE MAR,IA GRAüT.,IA PL.,.ENA DOMINU,.S TEC--UM",
                "INV  ENTA SUM DEI,..P-ARA ERGO IM-MACULATA.");

        areAnagrams("keEEP", "pE.EK");
        areAnagrams("ke.EP", "pEEK");
        areAnagrams("Am..pel", "P .,al,me");
        areAnagrams("T.- om Vo,.,rlost Riddle", "ist Lord Voldemort");
        areAnagrams("Dr-.,.-.acula", "ALu_CA&rüD");
        areAnagrams("Gäüiu l<i a S< ie g e l", "G%%iu§li*'*a Le+#geüäis");
        areAnagrams("enjooooy the day", "jooooy of s+#e da+#y");

        //leider sind Umlaute hier leider nicht inbegriffen...
    }


    public static boolean areAnagrams(String string1, String string2) {
        boolean current = true;
        //Alle Sonderzeichen und auch Lehrzeichen von den Strings replacen
        // und Kopien von den Parameterstrings anlegen
        String copyOfstring1 = string1.replaceAll("[^a-zA-Z]", "");
        String copyOfstring2 = string2.replaceAll("[^a-zA-Z]", "");
        //Damit wird schonmal alles rausgenommen, was nicht a-z oder A-Z ist.
        //Sind die Längen der Strings nicht gleich, kann man es sich nach der Modifikation sowieso gleich sparen!
        if (copyOfstring1.length() != copyOfstring2.length()) {
            current = false;
        } else {
            //damit des Uppercasing keine Probleme mocht.
            char[] lestring1Arr = copyOfstring1.toLowerCase().toCharArray();
            char[] lestring2Arr = copyOfstring2.toLowerCase().toCharArray();

            Arrays.sort(lestring1Arr);
            Arrays.sort(lestring2Arr);

            current = Arrays.equals(lestring1Arr, lestring2Arr);
        }
        if(current){
            System.out.println(string1+" und "+string2+" sind Anagramme.");
        } else {
            System.out.println(string1+" und "+string2+" sind keine Anagramme");
        }
        return false;
    }

}
